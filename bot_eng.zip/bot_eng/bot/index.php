<?php
session_start(); // Ensure the session is started

// Simulate admin login for testing functionality
$_SESSION['is_admin'] = true; // Change this value to test both admin and non-admin user

$isAdmin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chatbot</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e5ddd5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .chat-container {
            width: 400px;
            height: 600px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        .chat-box {
            flex: 1;
            padding: 10px;
            overflow-y: auto;
            background-color: #ece5dd;
        }
        .chat-input-container {
            display: flex;
            padding: 10px;
            background-color: #fff;
            border-top: 1px solid #ccc;
        }
        .chat-input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 20px;
            outline: none;
        }
        .button {
            background-color: #075e54;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 50%;
            cursor: pointer;
            margin-left: 5px;
        }
        .button:hover {
            background-color: #128c7e;
        }
        #reset-button {
            background-color: #dc3545;
        }
        #reset-button:hover {
            background-color: #c82333;
        }
        .message {
            margin-bottom: 10px;
            display: flex;
            width: 100%;
        }
        .user-message {
            justify-content: flex-end;
        }
        .bot-response {
            justify-content: flex-start;
        }
        .message span {
            padding: 10px;
            border-radius: 7.5px;
            display: inline-block;
            max-width: 80%;
            font-size: 14px;
            word-wrap: break-word;
        }
        .user-message span {
            background-color: #dcf8c6;
            color: #000;
            border: 1px solid #ccc;
        }
        .bot-response span {
            background-color: #fff;
            color: #000;
            border: 1px solid #ccc;
        }
        #teach-container {
            display: none; /* Initially hidden */
            padding: 10px;
            border-top: 1px solid #ccc;
            background-color: #fff;
            /* Temporarily force visibility for testing */
            /* display: block !important; */
        }
        .teach-input {
            width: calc(100% - 22px);
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 20px;
        }
        /* Style for the note */
        .note {
            color: red;
            font-size: 14px;
            margin-top: 10px;
            text-align: center; /* Center the note */
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-box" id="chat-box"></div>
        <div class="chat-input-container">
            <input type="text" class="chat-input" id="chat-input" placeholder="Type a message...">
            <button id="send-button" class="button">➤</button>
            <button id="reset-button" class="button">↺</button>
        </div>

        <?php if ($isAdmin): ?>
        <div id="teach-container">
            <h3>Teach the Bot</h3>
            <input type="text" class="teach-input" id="teach-keyword" placeholder="Keyword">
            <input type="text" class="teach-input" id="teach-response" placeholder="Response">
            <div class="button-container">
                <button id="teach-button" class="button">Teach</button>
                <a href="login.php" class="button">Login</a>
            </div>
            <p class="note">Only an administrator can teach the bot.</p>
        </div>
        <?php endif; ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var isAdmin = <?php echo json_encode($isAdmin); ?>;
            console.log("Is admin:", isAdmin);

            document.getElementById('send-button').addEventListener('click', function () {
                sendMessage();
            });

            document.getElementById('chat-input').addEventListener('keypress', function (e) {
                if (e.key === 'Enter') {
                    sendMessage();
                }
            });

            document.getElementById('reset-button').addEventListener('click', function () {
                resetChat();
            });

            function normalizeText(text) {
                // Decode HTML entities
                var txt = document.createElement("textarea");
                txt.innerHTML = text;
                return txt.value;
            }

            function sendMessage() {
                var message = document.getElementById('chat-input').value.trim();
                var chatBox = document.getElementById('chat-box');

                if (message === '') {
                    chatBox.innerHTML += '<div class="message bot-response"><span>Hello! How can I assist you today?</span></div>';
                    chatBox.scrollTop = chatBox.scrollHeight;
                    return;
                }

                document.getElementById('chat-input').value = '';

                chatBox.innerHTML += '<div class="message user-message"><span>' + message + '</span></div>';
                chatBox.scrollTop = chatBox.scrollHeight;

                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'chatbot.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onload = function () {
                    if (this.status === 200) {
                        var responseText = normalizeText(this.responseText);
                        console.log("Bot response:", responseText);

                        chatBox.innerHTML += '<div class="message bot-response"><span>' + responseText + '</span></div>';
                        chatBox.scrollTop = chatBox.scrollHeight;

                        if (responseText === "Sorry, I don't understand your question. Can you teach me how to respond?" && isAdmin) {
                            var teachContainer = document.getElementById('teach-container');
                            teachContainer.style.display = 'block'; // Force display

                            document.getElementById('teach-keyword').value = message;
                            console.log('Form displayed because bot did not understand and user is admin.');
                        } else {
                            console.log('Form not displayed. Either user is not admin or response was understood.');
                        }
                    } else {
                        console.error("Request error:", this.statusText);
                    }
                };
                xhr.onerror = function () {
                    console.error("Network error.");
                };
                xhr.send('message=' + encodeURIComponent(message));
            }

            function resetChat() {
                document.getElementById('chat-box').innerHTML = ''; 
                document.getElementById('chat-input').value = ''; 
                document.getElementById('teach-container').style.display = 'none';
                document.getElementById('teach-keyword').value = '';
                document.getElementById('teach-response').value = '';
            }

            document.getElementById('teach-button').addEventListener('click', function () {
                if (!isAdmin) {
                    alert("Only an administrator is authorized to teach the bot.");
                    return;
                }

                var keyword = document.getElementById('teach-keyword').value;
                var response = document.getElementById('teach-response').value;

                var xhr = new XMLHttpRequest();
                xhr.open('GET', 'chatbot.php?teach=1&keyword=' + encodeURIComponent(keyword) + '&response=' + encodeURIComponent(response), true);
                xhr.onload = function () {
                    if (this.status === 200) {
                        alert(this.responseText);
                        document.getElementById('teach-container').style.display = 'none';
                        document.getElementById('teach-keyword').value = '';
                        document.getElementById('teach-response').value = '';
                    } else {
                        console.error("Request error:", this.statusText);
                    }
                };
                xhr.onerror = function () {
                    console.error("Network error.");
                };
                xhr.send();
            });
        });
    </script>
</body>
</html>
