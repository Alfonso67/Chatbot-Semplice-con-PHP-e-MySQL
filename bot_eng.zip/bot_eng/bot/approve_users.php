<?php
session_start();
include 'db.php'; // Include the database connection

$conn = openDbConnection();

// Check if the user is an administrator
function isAdmin($conn) {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        
        $stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
        if (!$stmt) {
            die("Error preparing the query: " . $conn->error);
        }

        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($is_admin);
        $stmt->fetch();
        $stmt->close();

        return $is_admin == 1;
    }
    return false;
}

$message = ""; // Initialize the message variable

// Handle approval, rejection, revocation, role change, or deletion requests
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isAdmin($conn)) {
    $user_id = intval($_POST['user_id']);

    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        switch ($action) {
            case 'approve':
                $stmt = $conn->prepare("UPDATE users SET approved = 1 WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                break;
            case 'reject':
                $stmt = $conn->prepare("UPDATE users SET approved = 0 WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                break;
            case 'revoke':
                $stmt = $conn->prepare("UPDATE users SET approved = 0 WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                break;
            case 'change_role':
                $new_role = intval($_POST['new_role']);
                $stmt = $conn->prepare("UPDATE users SET is_admin = ? WHERE id = ?");
                $stmt->bind_param("ii", $new_role, $user_id);
                break;
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                break;
            default:
                $stmt = null;
                break;
        }

        if ($stmt && $stmt->execute()) {
            $message = "Action completed successfully.";
        } else {
            $message = "Error executing the action.";
        }

        if ($stmt) {
            $stmt->close();
        }
    }
}

// Display users and management options
if (isAdmin($conn)) {
    $result = $conn->query("SELECT id, username, approved, is_admin FROM users");

    if (!$result) {
        die("Error in the query: " . $conn->error);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Management</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .admin-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 100%;
            text-align: center;
        }
        .admin-container h1 {
            text-align: center;
            margin-top: 0;
        }
        .admin-container table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .admin-container table, .admin-container th, .admin-container td {
            border: 1px solid #ddd;
        }
        .admin-container th, .admin-container td {
            padding: 10px;
            text-align: center;
        }
        .admin-container th {
            background-color: #f2f2f2;
        }
        .admin-container form {
            display: inline;
        }
        .admin-container button {
            padding: 5px 10px;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 14px;
            cursor: pointer;
        }
        .admin-container button:hover {
            background-color: #0056b3;
        }
        .admin-container a {
            text-decoration: none;
            color: #007bff;
            margin-bottom: 20px;
            display: inline-block;
        }
        .admin-container a:hover {
            text-decoration: underline;
        }
        .message {
            text-align: center;
            color: green;
            margin-bottom: 20px;
        }
        .top-links {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="top-links">
            <a href='logout.php'>Logout</a>
            <a href='index.php'>Chatbot</a>
            <?php if (isAdmin($conn)) { ?>
                <a href='upload.php'>Teach the bot</a>
            <?php } ?>
        </div>
        <h1>User Management</h1>
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Status</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
            <?php
            while ($row = $result->fetch_assoc()) {
                $status = $row['approved'] ? "Approved" : "Not Approved";
                $role = $row['is_admin'] ? "Administrator" : "User";
                $new_role = $row['is_admin'] ? 0 : 1;
                $new_role_text = $row['is_admin'] ? "Make User" : "Make Admin";

                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                echo "<td>" . htmlspecialchars($status) . "</td>";
                echo "<td>" . htmlspecialchars($role) . "</td>";
                echo "<td>
                        <form method='post'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['id']) . "'>
                            <input type='hidden' name='action' value='approve'>
                            <button type='submit'>Approve</button>
                        </form>
                        <form method='post'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['id']) . "'>
                            <input type='hidden' name='action' value='reject'>
                            <button type='submit'>Reject</button>
                        </form>
                        <form method='post'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['id']) . "'>
                            <input type='hidden' name='action' value='revoke'>
                            <button type='submit'>Revoke</button>
                        </form>
                        <form method='post'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['id']) . "'>
                            <input type='hidden' name='action' value='change_role'>
                            <input type='hidden' name='new_role' value='" . htmlspecialchars($new_role) . "'>
                            <button type='submit'>" . htmlspecialchars($new_role_text) . "</button>
                        </form>
                        <form method='post'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['id']) . "'>
                            <input type='hidden' name='action' value='delete'>
                            <button type='submit'>Delete</button>
                        </form>
                      </td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>

<?php
} else {
    echo "<script>alert('Unauthorized access.'); window.location.href = 'index.php';</script>";
}

$conn->close();
?>
