<?php
session_start();
include 'db.php';

$conn = openDbConnection();
 
// Function to check if the user is authenticated, approved, and an administrator
function isAuthenticatedAndApproved() {
    if (isset($_SESSION['user_id'])) {
        $conn = openDbConnection();
        $user_id = $_SESSION['user_id'];
        
        $stmt = $conn->prepare("SELECT approved, is_admin FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($approved, $is_admin);
        $stmt->fetch();
        $stmt->close();
        $conn->close();

        return $approved == 1 && $is_admin == 1; // Must be approved and an administrator
    }
    return false;
}
// Check if the user is authenticated and approved
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['teach'])) {
    if (!isAuthenticatedAndApproved()) {
        echo htmlspecialchars("Unauthorized access. Only administrators can teach the Bot.", ENT_QUOTES, 'UTF-8');
        exit;
    }

    $keyword = trim($_GET['keyword']);
    $response = trim($_GET['response']);
    
    if (empty($keyword) || empty($response)) {
        echo htmlspecialchars("Keyword or response cannot be empty.", ENT_QUOTES, 'UTF-8');
        exit;
    }

    $conn = openDbConnection();

    $stmt = $conn->prepare("INSERT INTO learned_responses (keyword, response) VALUES (?, ?)");
    $stmt->bind_param("ss", $keyword, $response);
    $stmt->execute();
    $stmt->close();

    deleteDefaultResponses($conn);
    echo htmlspecialchars("Thank you! I have learned a new response.", ENT_QUOTES, 'UTF-8');
}
 
// Set the correct time zone and locale
date_default_timezone_set('Europe/London');

// Function to calculate the Levenshtein distance between two strings
function levenshteinDistance($str1, $str2) {
    return levenshtein($str1, $str2);
}

// Function to calculate the cosine similarity score between two strings
function cosineSimilarity($str1, $str2) {
    $vector1 = array_count_values(str_word_count(strtolower($str1), 1));
    $vector2 = array_count_values(str_word_count(strtolower($str2), 1));
    $intersection = array_intersect_key($vector1, $vector2);
    $dotProduct = array_sum(array_map(function ($a, $b) { return $a * $b; }, $intersection, $vector2));
    $magnitude1 = sqrt(array_sum(array_map(function ($a) { return $a * $a; }, $vector1)));
    $magnitude2 = sqrt(array_sum(array_map(function ($a) { return $a * $a; }, $vector2)));
    return $magnitude1 && $magnitude2 ? $dotProduct / ($magnitude1 * $magnitude2) : 0;
}
// Function to retrieve all keywords from the database
function getAllKeywords($conn) {
    $keywords = [];
    $stmt = $conn->prepare("SELECT keyword FROM learned_responses");
    $stmt->execute();
    $stmt->bind_result($keyword);
    while ($stmt->fetch()) {
        $keywords[] = $keyword;
    }
    $stmt->close();
    return $keywords;
}

// Function to retrieve a learned response based on a keyword
function getLearnedResponse($conn, $message) {
    $keywords = getAllKeywords($conn); // Function to retrieve all keywords from the database
    $preprocessedMessage = preprocessText($message);
    $minDistance = PHP_INT_MAX;
    $closestKeyword = null;
    $maxSimilarity = 0;

    foreach ($keywords as $keyword) {
        $preprocessedKeyword = preprocessText($keyword);
        // Calculates the Levenshtein distance and Cosine similarity
        $distance = levenshteinDistance($preprocessedMessage, $preprocessedKeyword);
        $similarity = cosineSimilarity($preprocessedMessage, $preprocessedKeyword);

        // Choose the most similar keyword with a similarity and distance threshold
        if ($distance < $minDistance || ($similarity > 0.6 && $distance <= 4)) { // Modifica la soglia di similarità
            $minDistance = $distance;
            $closestKeyword = $keyword;
            $maxSimilarity = $similarity;
        }
    }

    if ($minDistance <= 4 && $closestKeyword !== null && $maxSimilarity >= 0.6) { // Aumenta la soglia di similarità
        $stmt = $conn->prepare("SELECT response FROM learned_responses WHERE keyword = ? LIMIT 1");
        $stmt->bind_param("s", $closestKeyword);
        $stmt->execute();
        $stmt->bind_result($response);
        $stmt->fetch();
        $stmt->close();
        
        // If the message is close to a known keyword but not a typographical error
        if ($preprocessedMessage === preprocessText($closestKeyword)) {
            return $response;
        } else {
            return "I think you meant '$closestKeyword'? " . $response;
        }
    }

    return null;
}

// Function to preprocess messages and keywords
function preprocessText($text) {
    // Convert to lowercase and remove punctuation
    return strtolower(preg_replace('/[^\w\s]/', '', $text));
}

// Function to save a new learned response to the database
function saveLearnedResponse($conn, $keyword, $response) {
    $stmt = $conn->prepare("INSERT INTO learned_responses (keyword, response) VALUES (?, ?)");
    $stmt->bind_param("ss", $keyword, $response);
    $stmt->execute();
    $stmt->close();
}

// Function to delete default responses from the database
function deleteDefaultResponses($conn) {
    $stmt = $conn->prepare("DELETE FROM messages WHERE bot_response = ?");
    
    if ($stmt === false) {
        die("Error preparing delete query: " . $conn->error);
    }
    
    // Specifica la risposta predefinita da eliminare
    $defaultResponse = "Sorry, I don't understand your question. Can you teach me how to respond?";
    
    // Lega il parametro alla query
    $stmt->bind_param("s", $defaultResponse);
    
    if ($stmt->execute() === false) {
        die("Error executing delete query: " . $stmt->error);
    }
    
    $stmt->close();
}

// Function to get the current date and time in English
function getCurrentDateTime() {
    $now = new DateTime();

    $dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    $monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    return [
        'date' => $now->format('d/m/Y'),
        'time' => $now->format('H:i:s'),
        'year' => $now->format('Y'),
        'day' => $dayNames[$now->format('N') - 1],
        'month' => $monthNames[$now->format('n') - 1]
    ];
}

// Array of keywords for logout
$logoutKeywords = ['log me out', 'logout', 'log out', 'exit', 'end session', 'close session'];

// Array of keywords for login
$loginKeywords = ['log me in', 'login', 'log in', 'enter', 'start session', 'open session'];

// Array of keywords for user management
$manageUsersKeywords = ['manage users', 'administer users', 'approve users', 'user management'];

// Function to check if the message contains a specific keyword
function containsKeyword($message, $keywords) {
    foreach ($keywords as $keyword) {
        if (stripos($message, $keyword) !== false) {
            return true;
        }
    }
    return false;
}

// Handle chat request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
    $message = stripslashes($conn->real_escape_string($_POST['message']));

    // Check if the message contains a keyword for logout
    if (containsKeyword($message, $logoutKeywords)) {
        session_unset();
        session_destroy();

        // Show a logout message with a link to the login page
        echo "You have been logged out. <a href='login.php'>Return to the login page</a>";
        exit;
    }

    // Check if the message contains a keyword for login
    if (containsKeyword($message, $loginKeywords)) {
        echo "To log in, go to: <a href='login.php'>Login</a>";
        exit;
    }

    // Check if the message contains a keyword for user management
    if (containsKeyword($message, $manageUsersKeywords)) {
        echo "To manage users, go to the approval page: <a href='approve_users.php'>Manage Users</a>";
        exit;
    }
}

// Function to get the day of the week name
function getDayName($date) {
    $dayNames = ['Monday' => 'Monday', 'Tuesday' => 'Tuesday', 'Wednesday' => 'Wednesday', 'Thursday' => 'Thursday', 'Friday' => 'Friday', 'Saturday' => 'Saturday', 'Sunday' => 'Sunday'];
    $dateTime = DateTime::createFromFormat('d/m/Y', $date);
    return $dayNames[$dateTime->format('l')];
}

// Function to determine the correct response for time and date
function getTimeResponse($message) {
    $message = strtolower($message);
    $currentDateTime = getCurrentDateTime();
    $now = new DateTime();

    // Recognize phrases related to the time
    if (strpos($message, 'time') !== false || strpos($message, 'what time is it') !== false || strpos($message, 'what are the hours') !== false || strpos($message, 'give me the time') !== false) {
        return "The current time is " . $currentDateTime['time'] . ".";
    }

    // Recognize phrases related to the date
    if (strpos($message, 'date') !== false || strpos($message, 'what day is it') !== false || strpos($message, 'day') !== false) {
        if (strpos($message, 'tomorrow') !== false || strpos($message, 'next day') !== false) {
            $tomorrow = $now->modify('+1 day');
            $date = $tomorrow->format('d/m/Y');
            return "Tomorrow will be " . getDayName($date) . ", " . $date . ".";
        } elseif (strpos($message, 'yesterday') !== false || strpos($message, 'previous day') !== false) {
            $yesterday = $now->modify('-1 day');
            $date = $yesterday->format('d/m/Y');
            return "Yesterday was " . getDayName($date) . ", " . $date . ".";
        } else {
            return "Today is " . $currentDateTime['day'] . ", " . $currentDateTime['date'] . ".";
        }
    }
    
    // Function to recognize phrases related to the month
if (strpos($message, 'month') !== false) {
    return "We are in the month of " . $currentDateTime['month'] . ".";
}

// Function to recognize phrases related to the year
if (strpos($message, 'year') !== false || strpos($message, 'what year is it') !== false) {
    return "We are in the year " . $currentDateTime['year'] . ".";
}

// Function to recognize phrases related to the full date
if (strpos($message, 'full date') !== false || strpos($message, 'date and time') !== false) {
    return "Today is " . $currentDateTime['day'] . ", " . $currentDateTime['date'] . " and the current time is " . $currentDateTime['time'] . ".";
}

// Function to recognize phrases related to time intervals
if (strpos($message, 'in how long') !== false || strpos($message, 'how long until') !== false) {
    preg_match('/(\d+)\s*(days|day|weeks|week)/', $message, $matches);
    if (isset($matches[1]) && isset($matches[2])) {
        $interval = new DateInterval('P' . $matches[1] . strtoupper(substr($matches[2], 0, 1)));
        $futureDate = $now->add($interval);
        $date = $futureDate->format('d/m/Y');
        return "In " . $matches[1] . " " . $matches[2] . " it will be " . getDayName($date) . ", " . $date . ".";
    }
}

return false;
}

// Function to identify the user's name from the message
function getUserName($message) {
    // Common patterns to recognize names
    $patterns = [
        '/my name is (\w+)/i',
        '/i am (\w+)/i',
        '/i am (\w+)/i',
        '/my name is (\w+)/i',
        '/let me introduce myself, (\w+)/i',
        '/my name is (\w+)\s*$/i', // Allow "my name is" at the end of the message
        '/i am (\w+)\s*$/i', // Allow "i am" at the end of the message
        '/i am (\w+)\s*$/i', // Allow "i am" at the end of the message
        '/my name is (\w+)\s*$/i', // Allow "my name is" at the end of the message
        '/let me introduce myself, (\w+)\s*$/i' // Allow "let me introduce myself, " at the end of the message
    ];

    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $message, $matches)) {
            return $matches[1];
        }
    }

    return null;
}

// Function to get the user's name from the database
function getUserNameFromDB($conn, $userId) {
    $stmt = $conn->prepare("SELECT name FROM user_names WHERE user_id = ? LIMIT 1");
    $stmt->bind_param("s", $userId);
    $stmt->execute();
    $stmt->bind_result($username);
    $stmt->fetch();
    $stmt->close();
    return $username;
}

// Function to save the user's name in the database
function saveUserName($conn, $userId, $username) {
    $stmt = $conn->prepare("INSERT INTO user_names (user_id, name) VALUES (?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name)");
    $stmt->bind_param("ss", $userId, $username);
    $stmt->execute();
    $stmt->close();
}

// Function to reset the user's name in the database
function resetUserName($conn, $userId) {
    $stmt = $conn->prepare("DELETE FROM user_names WHERE user_id = ?");
    $stmt->bind_param("s", $userId);
    $stmt->execute();
    $stmt->close();
}

// Main function to get a response from the chatbot
function getResponse($conn, $message, $userId) {
    $cleanedMessage = strtolower(trim($message));

    // Check if the message is a reset command
    if ($cleanedMessage == 'reset') {
        resetUserName($conn, $userId);
        return "The conversation has been reset.";
    }

    // Retrieve the user's name from the database
    $userName = getUserNameFromDB($conn, $userId);

    // Common words to ignore as names
    $commonWords = ['now', 'thank you', 'pleased', 'today', 'tomorrow', 'returned', 'came back', 'I arrived', 'sorry'];

    // Check and save the user's name from the message
    $userNameInMessage = getUserName($message);
    if ($userNameInMessage && !in_array($userNameInMessage, $commonWords)) {
        saveUserName($conn, $userId, $userNameInMessage);
        return "Nice to meet you, $userNameInMessage!";
    }

    // Define greeting variants
    $greetings = [
        'hello', 'hi', 'good morning', 'good afternoon', 'good evening', 'good night', 'hey', 'hola'
    ];

    // Define farewell variants
    $farewells = [
        'goodbye', 'farewell', 'see you soon', 'see you', 'goodbye', 'good night', 'I have to go'
    ];

    // Define farewell responses
    $farewellResponses = [
        'Goodbye', 'Farewell', 'See you soon', 'See you', 'Goodbye', 'Good night'
    ];

    // Check if the message contains a greeting variant
    foreach ($greetings as $greeting) {
        if (stripos($cleanedMessage, $greeting) !== false) {
            return $userName ? ucfirst($greeting) . " $userName! How can I assist you today?" : ucfirst($greeting) . "! How can I assist you today?";
        }
    }

    // Check if the message contains a farewell variant
    foreach ($farewells as $key => $farewell) {
        if (stripos($cleanedMessage, $farewell) !== false) {
            
            // Reset the user's name when the conversation ends
            resetUserName($conn, $userId);
             
            // Select the corresponding farewell response
            $response = $farewellResponses[$key] ?? 'Goodbye';
            return $userName ? "$response $userName!" : "$response!";
        }
    }

    // Check if the message is about the creation date
    if (stripos($cleanedMessage, 'creation date') !== false || 
        stripos($cleanedMessage, 'when were you created') !== false ||
        stripos($cleanedMessage, 'date of creation') !== false ||
        stripos($cleanedMessage, 'when were you created') !== false) {
        return "The creation date of the chatbot is " . getCreationDate() . ".";
    }

    // Check if the message is about the bot's name
    if (stripos($cleanedMessage, 'what is your name') !== false) {
        return "My name is ChatBot! Nice to meet you.";
    }

    // Check if the message is about the bot's introduction
    if (stripos($cleanedMessage, 'who are you') !== false || stripos($cleanedMessage, 'what do you do') !== false || stripos($cleanedMessage, 'what can you do') !== false) {
        return $userName ? "Hi $userName! I am a chatbot designed to help you with your questions. I can tell you the time, the date, answer common questions, and even learn new responses if you teach me. How can I assist you today?" : "Hi! I am a chatbot designed to help you with your questions. I can tell you the time, the date, answer common questions, and even learn new responses if you teach me. How can I assist you today?";
    }

    // Get a learned response from the database with automatic correction
    $learnedResponse = getLearnedResponse($conn, $cleanedMessage);
    if ($learnedResponse) {
        return $userName ? str_replace('[name]', $userName, $learnedResponse) : $learnedResponse;
    }

    // Determine the correct response for time and date
    $timeResponse = getTimeResponse($cleanedMessage);
    if ($timeResponse) {
        return $timeResponse;
    }

    // Default response if the bot doesn't understand
    return "Sorry, I don't understand your question. Can you teach me how to respond?";
}

// Function to get the creation date
function getCreationDate() {
    return '25/07/2024'; // Insert the chatbot creation date here
}

// Check if there is already a user ID in the session
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = bin2hex(random_bytes(16)); // Generate a unique ID for the user
}

$userId = $_SESSION['user_id'];

// Handle POST requests for conversations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userMessage = stripslashes($conn->real_escape_string($_POST['message']));

    if (empty($userMessage)) {
        echo htmlspecialchars("You need to type something", ENT_QUOTES, 'UTF-8');
        exit();
    }

    $botResponse = getResponse($conn, $userMessage, $userId);

    // Save the message and response to the database
    $stmt = $conn->prepare("INSERT INTO messages (user_message, bot_response) VALUES (?, ?)");
    if ($stmt === false) {
        die("Error preparing query: " . $conn->error);
    }
    $stmt->bind_param("ss", $userMessage, $botResponse);
    if ($stmt->execute() === false) {
        die("Error executing query: " . $stmt->error);
    }
    $stmt->close();

    // Output the bot's response
    echo htmlspecialchars($botResponse, ENT_QUOTES, 'UTF-8');
}
?>