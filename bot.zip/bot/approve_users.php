<?php
session_start();
include 'db.php'; // Include la connessione al database

$conn = openDbConnection();

// Verifica se l'utente è amministratore
function isAdmin($conn) {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        
        $stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
        if (!$stmt) {
            die("Errore nella preparazione della query: " . $conn->error);
        }

        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($is_admin);
        $stmt->fetch();
        $stmt->close();

        return $is_admin == 1;
    }
    return false;
}

$message = ""; // Inizializza la variabile del messaggio

// Gestione della richiesta di approvazione, rifiuto, revoca, cambio ruolo o eliminazione
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isAdmin($conn)) {
    $user_id = intval($_POST['user_id']);

    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        switch ($action) {
            case 'approve':
                $stmt = $conn->prepare("UPDATE users SET approved = 1 WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                break;
            case 'reject':
                $stmt = $conn->prepare("UPDATE users SET approved = 0 WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                break;
            case 'revoke':
                $stmt = $conn->prepare("UPDATE users SET approved = 0 WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                break;
            case 'change_role':
                $new_role = intval($_POST['new_role']);
                $stmt = $conn->prepare("UPDATE users SET is_admin = ? WHERE id = ?");
                $stmt->bind_param("ii", $new_role, $user_id);
                break;
            case 'delete':
                $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
                $stmt->bind_param("i", $user_id);
                break;
            default:
                $stmt = null;
                break;
        }

        if ($stmt && $stmt->execute()) {
            $message = "Azione completata con successo.";
        } else {
            $message = "Errore durante l'esecuzione dell'azione.";
        }

        if ($stmt) {
            $stmt->close();
        }
    }
}

// Mostra gli utenti e le opzioni di gestione
if (isAdmin($conn)) {
    $result = $conn->query("SELECT id, username, approved, is_admin FROM users");

    if (!$result) {
        die("Errore nella query: " . $conn->error);
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Gestione Utenti</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .admin-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 100%;
            text-align: center;
        }
        .admin-container h1 {
            text-align: center;
            margin-top: 0;
        }
        .admin-container table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .admin-container table, .admin-container th, .admin-container td {
            border: 1px solid #ddd;
        }
        .admin-container th, .admin-container td {
            padding: 10px;
            text-align: center;
        }
        .admin-container th {
            background-color: #f2f2f2;
        }
        .admin-container form {
            display: inline;
        }
        .admin-container button {
            padding: 5px 10px;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 14px;
            cursor: pointer;
        }
        .admin-container button:hover {
            background-color: #0056b3;
        }
        .admin-container a {
            text-decoration: none;
            color: #007bff;
            margin-bottom: 20px;
            display: inline-block;
        }
        .admin-container a:hover {
            text-decoration: underline;
        }
        .message {
            text-align: center;
            color: green;
            margin-bottom: 20px;
        }
        .top-links {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div class="top-links">
            <a href='logout.php'>Logout</a>
            <a href='index.php'>Chatbot</a>
        </div>
        <h1>Gestione Utenti</h1>
        <?php if ($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>
        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Stato</th>
                <th>Ruolo</th>
                <th>Azioni</th>
            </tr>
            <?php
            while ($row = $result->fetch_assoc()) {
                $status = $row['approved'] ? "Approvato" : "Non Approvato";
                $role = $row['is_admin'] ? "Amministratore" : "Utente";
                $new_role = $row['is_admin'] ? 0 : 1;
                $new_role_text = $row['is_admin'] ? "Rendi Utente" : "Rendi Admin";

                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                echo "<td>" . htmlspecialchars($status) . "</td>";
                echo "<td>" . htmlspecialchars($role) . "</td>";
                echo "<td>
                        <form method='post'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['id']) . "'>
                            <input type='hidden' name='action' value='approve'>
                            <button type='submit'>Approva</button>
                        </form>
                        <form method='post'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['id']) . "'>
                            <input type='hidden' name='action' value='reject'>
                            <button type='submit'>Rifiuta</button>
                        </form>
                        <form method='post'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['id']) . "'>
                            <input type='hidden' name='action' value='revoke'>
                            <button type='submit'>Revoca</button>
                        </form>
                        <form method='post'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['id']) . "'>
                            <input type='hidden' name='action' value='change_role'>
                            <input type='hidden' name='new_role' value='" . htmlspecialchars($new_role) . "'>
                            <button type='submit'>" . htmlspecialchars($new_role_text) . "</button>
                        </form>
                        <form method='post'>
                            <input type='hidden' name='user_id' value='" . htmlspecialchars($row['id']) . "'>
                            <input type='hidden' name='action' value='delete'>
                            <button type='submit'>Elimina</button>
                        </form>
                      </td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
</body>
</html>

<?php
} else {
    echo "<script>alert('Accesso non autorizzato.'); window.location.href = 'index.php';</script>";
}

$conn->close();
?>
