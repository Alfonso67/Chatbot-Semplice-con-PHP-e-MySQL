<?php
session_start();
include 'db.php';

$conn = openDbConnection();
 
// Funzione per verificare se l'utente è autenticato, approvato e amministratore
function isAuthenticatedAndApproved() {
    if (isset($_SESSION['user_id'])) {
        $conn = openDbConnection();
        $user_id = $_SESSION['user_id'];
        
        $stmt = $conn->prepare("SELECT approved, is_admin FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($approved, $is_admin);
        $stmt->fetch();
        $stmt->close();
        $conn->close();

        return $approved == 1 && $is_admin == 1; // Deve essere approvato e amministratore
    }
    return false;
}
// Verifica se l'utente è autenticato e approvato
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['teach'])) {
    if (!isAuthenticatedAndApproved()) {
        echo htmlspecialchars("Accesso non autorizzato. Solo gli amministratori possono insegnare al Bot", ENT_QUOTES, 'UTF-8');
        exit;
    }

    // Connessione al database
    $conn = openDbConnection();

    // Gestione della richiesta di insegnamento
    $keyword = stripslashes($conn->real_escape_string($_GET['keyword']));
    $response = stripslashes($conn->real_escape_string($_GET['response']));
    saveLearnedResponse($conn, $keyword, $response);
    deleteDefaultResponses($conn);
    echo htmlspecialchars("Grazie! Ho imparato una nuova risposta.", ENT_QUOTES, 'UTF-8');

}

// Funzione per verificare se l'utente è admin
function isAdmin($conn) {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];

        $stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($is_admin);
        $stmt->fetch();
        $stmt->close();

        return $is_admin == 1;
    }
    return false;
}

// Imposta il fuso orario corretto e il locale
date_default_timezone_set('Europe/Rome');

// Funzione per calcolare la distanza di Levenshtein tra due stringhe
function levenshteinDistance($str1, $str2) {
    return levenshtein($str1, $str2);
}

// Funzione per calcolare il punteggio di similarità di Coseno tra due stringhe
function cosineSimilarity($str1, $str2) {
    $vector1 = array_count_values(str_word_count(strtolower($str1), 1));
    $vector2 = array_count_values(str_word_count(strtolower($str2), 1));
    $intersection = array_intersect_key($vector1, $vector2);
    $dotProduct = array_sum(array_map(function ($a, $b) { return $a * $b; }, $intersection, $vector2));
    $magnitude1 = sqrt(array_sum(array_map(function ($a) { return $a * $a; }, $vector1)));
    $magnitude2 = sqrt(array_sum(array_map(function ($a) { return $a * $a; }, $vector2)));
    return $magnitude1 && $magnitude2 ? $dotProduct / ($magnitude1 * $magnitude2) : 0;
}
// Funzione per ottenere tutte le parole chiave dal database
function getAllKeywords($conn) {
    $keywords = [];
    $stmt = $conn->prepare("SELECT keyword FROM learned_responses");
    $stmt->execute();
    $stmt->bind_result($keyword);
    while ($stmt->fetch()) {
        $keywords[] = $keyword;
    }
    $stmt->close();
    return $keywords;
}

// Funzione per ottenere una risposta appresa basata su una parola chiave
function getLearnedResponse($conn, $message) {
    $keywords = getAllKeywords($conn); // Recupera tutte le parole chiave dal database
    $preprocessedMessage = preprocessText($message);
    $minDistance = PHP_INT_MAX;
    $closestKeyword = null;
    $maxSimilarity = 0;

    foreach ($keywords as $keyword) {
        $preprocessedKeyword = preprocessText($keyword);
        // Calcola la distanza di Levenshtein e la similarità di Coseno
        $distance = levenshteinDistance($preprocessedMessage, $preprocessedKeyword);
        $similarity = cosineSimilarity($preprocessedMessage, $preprocessedKeyword);

        // Scegli la parola chiave più simile con una soglia di similarità e distanza
        if ($distance < $minDistance || ($similarity > 0.6 && $distance <= 4)) { // Modifica la soglia di similarità
            $minDistance = $distance;
            $closestKeyword = $keyword;
            $maxSimilarity = $similarity;
        }
    }

    if ($minDistance <= 4 && $closestKeyword !== null && $maxSimilarity >= 0.6) { // Aumenta la soglia di similarità
        $stmt = $conn->prepare("SELECT response FROM learned_responses WHERE keyword = ? LIMIT 1");
        $stmt->bind_param("s", $closestKeyword);
        $stmt->execute();
        $stmt->bind_result($response);
        $stmt->fetch();
        $stmt->close();
        
        // Se il messaggio è vicino a una parola chiave conosciuta ma non è un errore di battitura
        if ($preprocessedMessage === preprocessText($closestKeyword)) {
            return $response;
        } else {
            return "Penso che tu volessi dire '$closestKeyword'? " . $response;
        }
    }

    return null;
}

//Funzione per preprocessare i messaggi e le parole chiave
function preprocessText($text) {
    // Converti in minuscolo e rimuovi punteggiatura
    return strtolower(preg_replace('/[^\w\s]/', '', $text));
}

// Funzione per salvare una nuova risposta appresa nel database
function saveLearnedResponse($conn, $keyword, $response) {
    $stmt = $conn->prepare("INSERT INTO learned_responses (keyword, response) VALUES (?, ?)");
    $stmt->bind_param("ss", $keyword, $response);
    $stmt->execute();
    $stmt->close();
}

// Funzione per eliminare le risposte predefinite dal database
function deleteDefaultResponses($conn) {
    $stmt = $conn->prepare("DELETE FROM messages WHERE bot_response = 'Mi dispiace, non capisco la tua domanda. Puoi insegnarmi come rispondere?'");
    if ($stmt === false) {
        die("Errore nella preparazione della query di eliminazione: " . $conn->error);
    }
    if ($stmt->execute() === false) {
        die("Errore nell'esecuzione della query di eliminazione: " . $stmt->error);
    }
    $stmt->close();
}

// Funzione per ottenere la data e l'ora corrente in italiano
function getCurrentDateTime() {
    $now = new DateTime();

    $dayNames = ['Monday' => 'Lunedì', 'Tuesday' => 'Martedì', 'Wednesday' => 'Mercoledì', 'Thursday' => 'Giovedì', 'Friday' => 'Venerdì', 'Saturday' => 'Sabato', 'Sunday' => 'Domenica'];
    $monthNames = ['January' => 'Gennaio', 'February' => 'Febbraio', 'March' => 'Marzo', 'April' => 'Aprile', 'May' => 'Maggio', 'June' => 'Giugno', 'July' => 'Luglio', 'August' => 'Agosto', 'September' => 'Settembre', 'October' => 'Ottobre', 'November' => 'Novembre', 'December' => 'Dicembre'];

    return [
        'date' => $now->format('d/m/Y'),
        'time' => $now->format('H:i:s'),
        'year' => $now->format('Y'),
        'day' => $dayNames[$now->format('l')],
        'month' => $monthNames[$now->format('F')]
    ];
}
// Array di parole chiave per il logout
$logoutKeywords = ['disconnettimi', 'disconnetti', 'logout', 'esci', 'termina la sessione', 'chiudi la sessione'];

// Array di parole chiave per il login
$loginKeywords = ['connettimi', 'connetti', 'login', 'entra', 'inizia la sessione', 'apri la sessione'];

// Array di parole chiave per la gestione degli utenti
$manageUsersKeywords = ['gestisci utenti', 'amministra utenti', 'approva utenti', 'gestione utenti'];

// Funzione per verificare se il messaggio contiene una parola chiave specifica
function containsKeyword($message, $keywords) {
    foreach ($keywords as $keyword) {
        if (stripos($message, $keyword) !== false) {
            return true;
        }
    }
    return false;
}

// Gestione della richiesta di chat
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
    $message = stripslashes($conn->real_escape_string($_POST['message']));

    // Verifica se il messaggio contiene una parola chiave per il logout
    if (containsKeyword($message, $logoutKeywords)) {
        session_unset();
        session_destroy();

        // Mostra un messaggio di disconnessione con un link alla pagina di login
        echo "Sei stato disconnesso. <a href='login.php'>Torna alla pagina di login</a>";
        exit;
    }

// Verifica se il messaggio contiene una parola chiave per il login
if (containsKeyword($message, $loginKeywords)) {
    echo "Per effettuare il login, vai alla pagina: <a href='login.php'>Login</a>";
    exit;
}
    // Verifica se il messaggio contiene una parola chiave per la gestione degli utenti
    if (containsKeyword($message, $manageUsersKeywords)) {
        echo "Per gestire gli utenti, vai alla pagina di approvazione: <a href='approve_users.php'>Gestisci Utenti</a>";
        exit;
    }
}

// Funzione per ottenere il nome del giorno della settimana
function getDayName($date) {
    $dayNames = ['Monday' => 'Lunedì', 'Tuesday' => 'Martedì', 'Wednesday' => 'Mercoledì', 'Thursday' => 'Giovedì', 'Friday' => 'Venerdì', 'Saturday' => 'Sabato', 'Sunday' => 'Domenica'];
    $dateTime = DateTime::createFromFormat('d/m/Y', $date);
    return $dayNames[$dateTime->format('l')];
}

// Funzione per determinare la risposta corretta per l'ora e la data
function getTimeResponse($message) {
    $message = strtolower($message);
    $currentDateTime = getCurrentDateTime();
    $now = new DateTime();

    // Riconoscimento delle frasi riguardanti l'ora
    if (strpos($message, 'ora') !== false || strpos($message, 'che ora è') !== false || strpos($message, 'che ore sono') !== false || strpos($message, 'dammi l\'ora') !== false) {
        return "L'ora corrente è " . $currentDateTime['time'] . ".";
    }

    // Riconoscimento delle frasi riguardanti la data
    if (strpos($message, 'data') !== false || strpos($message, 'che giorno è') !== false || strpos($message, 'giorno') !== false) {
        if (strpos($message, 'domani') !== false || strpos($message, 'giorno successivo') !== false) {
            $tomorrow = $now->modify('+1 day');
            $date = $tomorrow->format('d/m/Y');
            return "Domani sarà " . getDayName($date) . ", " . $date . ".";
        } elseif (strpos($message, 'ieri') !== false || strpos($message, 'giorno precedente') !== false) {
            $yesterday = $now->modify('-1 day');
            $date = $yesterday->format('d/m/Y');
            return "Ieri era " . getDayName($date) . ", " . $date . ".";
        } else {
            return "Oggi è " . $currentDateTime['day'] . ", " . $currentDateTime['date'] . ".";
        }
    }

    // Riconoscimento delle frasi riguardanti il mese
    if (strpos($message, 'mese') !== false) {
        return "Siamo nel mese di " . $currentDateTime['month'] . ".";
    }

    // Riconoscimento delle frasi riguardanti l'anno
    if (strpos($message, 'anno') !== false || strpos($message, 'in che anno siamo') !== false) {
        return "Siamo nell'anno " . $currentDateTime['year'] . ".";
    }

    // Riconoscimento delle frasi riguardanti la data completa
    if (strpos($message, 'data completa') !== false || strpos($message, 'data e ora') !== false) {
        return "Oggi è " . $currentDateTime['day'] . ", " . $currentDateTime['date'] . " e l'ora corrente è " . $currentDateTime['time'] . ".";
    }

    // Riconoscimento delle frasi riguardanti intervalli di tempo
    if (strpos($message, 'tra quanto') !== false || strpos($message, 'fra quanto') !== false) {
        preg_match('/(\d+)\s*(giorni|giorno|settimane|settimana)/', $message, $matches);
        if (isset($matches[1]) && isset($matches[2])) {
            $interval = new DateInterval('P' . $matches[1] . strtoupper(substr($matches[2], 0, 1)));
            $futureDate = $now->add($interval);
            $date = $futureDate->format('d/m/Y');
            return "Tra " . $matches[1] . " " . $matches[2] . " sarà " . getDayName($date) . ", " . $date . ".";
        }
    }

    return false;
}

// Funzione per identificare il nome dell'utente nel messaggio
function getUserName($message) {
    // Pattern comuni per riconoscere i nomi
    $patterns = [
        '/mi chiamo (\w+)/i',
        '/io sono (\w+)/i',
        '/sono (\w+)/i',
        '/il mio nome è (\w+)/i',
        '/mi presento, (\w+)/i',
        '/mi chiamo (\w+)\s*$/i', // Permettere "mi chiamo" alla fine del messaggio
        '/io sono (\w+)\s*$/i', // Permettere "io sono" alla fine del messaggio
        '/sono (\w+)\s*$/i', // Permettere "sono" alla fine del messaggio
        '/il mio nome è (\w+)\s*$/i', // Permettere "il mio nome è" alla fine del messaggio
        '/mi presento, (\w+)\s*$/i' // Permettere "mi presento, " alla fine del messaggio
    ];

    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $message, $matches)) {
            return $matches[1];
        }
    }

    return null;
}

// Funzione per ottenere il nome dell'utente dal database
function getUserNameFromDB($conn, $userId) {
    $stmt = $conn->prepare("SELECT name FROM user_names WHERE user_id = ? LIMIT 1");
    $stmt->bind_param("s", $userId);
    $stmt->execute();
    $stmt->bind_result($username);
    $stmt->fetch();
    $stmt->close();
    return $username;
}

// Funzione per salvare il nome dell'utente nel database
function saveUserName($conn, $userId, $username) {
    $stmt = $conn->prepare("INSERT INTO user_names (user_id, name) VALUES (?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name)");
    $stmt->bind_param("ss", $userId, $username);
    $stmt->execute();
    $stmt->close();
}

// Funzione per resettare il nome dell'utente nel database
function resetUserName($conn, $userId) {
    $stmt = $conn->prepare("DELETE FROM user_names WHERE user_id = ?");
    $stmt->bind_param("s", $userId);
    $stmt->execute();
    $stmt->close();
}

// Funzione principale per ottenere una risposta dal chatbot
function getResponse($conn, $message, $userId) {
    $cleanedMessage = strtolower(trim($message));

    // Verifica se il messaggio è un comando di reset
    if ($cleanedMessage == 'reset') {
        resetUserName($conn, $userId);
        return "La conversazione è stata resettata.";
    }

     // Aggiungere il controllo per il logout


    // Recupera il nome dell'utente dal database
    $userName = getUserNameFromDB($conn, $userId);

    // Lista di parole comuni da ignorare come nomi
    $commonWords = ['adesso', 'grazie', 'piacere', 'oggi', 'domani','tornato','ritornato','sono arrivato','scusami'];

    // Verifica e memorizza il nome dell'utente nel messaggio
    $userNameInMessage = getUserName($message);
    if ($userNameInMessage && !in_array($userNameInMessage, $commonWords)) {
        saveUserName($conn, $userId, $userNameInMessage);
        return "Piacere di conoscerti, $userNameInMessage!";
    }

    // Definire le varianti di saluti
    $greetings = [
        'ciao', 'salve', 'buongiorno', 'buon giorno', 'buonasera', 'buona sera', 'buonanotte', 'buona notte', 'buonpomeriggio', 'buon pomeriggio', 'hey', 'hola'
    ];

    // Definire i saluti di congedo
    $farewells = [
        'arrivederci', 'addio', 'a presto', 'ci vediamo', 'a domani', 'buonanotte', 'buona notte', 'devo andare'
    ];

    // Definire le risposte di congedo
     $farewellResponses = [
    'Arrivederci', 'Addio', 'A presto', 'Ci vediamo', 'A domani', 'Buonanotte', 'Buona notte'
    ];

    // Controllare se il messaggio contiene una delle varianti di saluto
    foreach ($greetings as $greeting) {
        if (stripos($cleanedMessage, $greeting) !== false) {
            return $userName ? ucfirst($greeting) . " $userName! Come posso aiutarti oggi?" : ucfirst($greeting) . "! Come posso aiutarti oggi?";
        }
    }

    // Controllare se il messaggio contiene una delle varianti di congedo
    foreach ($farewells as $key =>$farewell) {
        if (stripos($cleanedMessage, $farewell) !== false) {
            
            // Resetta il nome dell'utente quando la conversazione si chiude
            resetUserName($conn, $userId);
             
             // Seleziona la risposta di congedo corrispondente
             $response = $farewellResponses[$key] ?? 'Arrivederci';
             return $userName ? "$response $userName!" : "$response!";
        }
    }

    // Aggiungere un controllo specifico per la data di creazione
    if (stripos($cleanedMessage, 'data della tua creazione') !== false || 
        stripos($cleanedMessage, 'quando sei stato creato') !== false ||
        stripos($cleanedMessage, 'data di creazione') !== false ||
        stripos($cleanedMessage, 'quando sei stato creato') !== false) {
        return "La data di creazione del chatbot è " . getCreationDate() . ".";
    }

    // Controllare se il messaggio riguarda il nome del bot
    if (stripos($cleanedMessage, 'come ti chiami') !== false) {
        return "Mi chiamo ChatBot! Piacere di conoscerti.";
    }

    // Controllare se il messaggio riguarda la presentazione del bot
    if (stripos($cleanedMessage, 'chi sei') !== false || stripos($cleanedMessage, 'cosa fai') !== false || stripos($cleanedMessage, 'cosa puoi fare') !== false) {
        return $userName ? "Ciao $userName! Sono un chatbot progettato per aiutarti con le tue domande. Posso dirti l'ora, la data, rispondere a domande comuni, e anche imparare nuove risposte se mi insegni. Come posso aiutarti oggi?" : "Ciao! Sono un chatbot progettato per aiutarti con le tue domande. Posso dirti l'ora, la data, rispondere a domande comuni, e anche imparare nuove risposte se mi insegni. Come posso aiutarti oggi?";
    }

    // Ottenere una risposta appresa dal database con correzione automatica
    $learnedResponse = getLearnedResponse($conn, $cleanedMessage);
    if ($learnedResponse) {
        return $userName ? str_replace('[nome]', $userName, $learnedResponse) : $learnedResponse;
    }

    // Determinare la risposta corretta per l'ora e la data
    $timeResponse = getTimeResponse($cleanedMessage);
    if ($timeResponse) {
        return $timeResponse;
    }

    // Risposta predefinita se il bot non capisce
    return "Mi dispiace, non capisco la tua domanda. Puoi insegnarmi come rispondere?";
}

//Funzione per ottenere la data della creazione
function getCreationDate() {
    return '25/07/2024'; // Inserisci qui la data di creazione del chatbot
}
 
// Verifica se esiste già un ID utente nella sessione
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = bin2hex(random_bytes(16)); // Genera un ID univoco per l'utente
}

$userId = $_SESSION['user_id'];

// Gestione delle richieste POST per le conversazioni
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $userMessage = stripslashes($conn->real_escape_string($_POST['message']));

    if (empty($userMessage)) {
        echo htmlspecialchars("Devi digitare qualcosa", ENT_QUOTES, 'UTF-8');
        exit();
    }

    $botResponse = getResponse($conn, $userMessage, $userId);

    // Salvare il messaggio e la risposta nel database
    $stmt = $conn->prepare("INSERT INTO messages (user_message, bot_response) VALUES (?, ?)");
    if ($stmt === false) {
        die("Errore nella preparazione della query: " . $conn->error);
    }
    $stmt->bind_param("ss", $userMessage, $botResponse);
    if ($stmt->execute() === false) {
        die("Errore nell'esecuzione della query: " . $stmt->error);
    }
    $stmt->close();

    // Risposta del bot
    echo htmlspecialchars($botResponse, ENT_QUOTES, 'UTF-8');
}
?>