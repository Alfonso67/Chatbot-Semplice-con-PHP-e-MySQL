<?php
session_start();
include 'db.php';

$conn = openDbConnection(); // Crea la connessione al database

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = stripslashes($_POST['username']);
    $password = stripslashes($_POST['password']);
    
    $stmt = $conn->prepare("SELECT id, password, approved, is_admin FROM users WHERE username = ?");
    if ($stmt === false) {
        die("Errore nella preparazione della query: " . $conn->error);
    }
    
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($user_id, $hashed_password, $approved, $is_admin);
    
    if ($stmt->num_rows > 0) {
        $stmt->fetch();
        if (password_verify($password, $hashed_password) && $approved == 1) {
            $_SESSION['user_id'] = $user_id;
            header('Location: http://localhost/bot');
            exit;
        } else {
            $error = "Credenziali non valide o account non approvato.";
        }
    } else {
        $error = "Credenziali non valide.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
        }
        .login-container h2 {
            margin-top: 0;
            text-align: center;
        }
        .login-container label {
            display: block;
            margin: 15px 0 5px;
        }
        .login-container input[type="text"],
        .login-container input[type="password"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .button-container {
            display: flex;
            gap: 10px;
        }
        .button-container button {
            flex: 1;
            padding: 10px;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            box-sizing: border-box;
        }
        .button-container button:hover {
            background-color: #0056b3;
        }
        .button-container .register-button {
            background-color: #28a745;
        }
        .button-container .register-button:hover {
            background-color: #218838;
        }
        .login-container p {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <form method="post" action="">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <div class="button-container">
                <button type="submit">Login</button>
                <a href="create_admin.php" style="flex: 1;">
                    <button type="button" class="register-button" style="width: 100%;">Registrati</button>
                </a>
            </div>
            <?php if (isset($error)) echo "<p>$error</p>"; ?>
        </form>
    </div>
</body>
</html>
