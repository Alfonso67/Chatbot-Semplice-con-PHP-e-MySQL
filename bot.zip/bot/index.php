<?php
session_start(); // Assicurati che la sessione sia avviata

// Simula il login dell'admin per testare la funzionalità
$_SESSION['is_admin'] = true; // Modifica questo valore per testare sia come admin che come utente non admin

$isAdmin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Chatbot</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #e5ddd5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .chat-container {
            width: 400px;
            height: 600px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        .chat-box {
            flex: 1;
            padding: 10px;
            overflow-y: auto;
            background-color: #ece5dd;
        }
        .chat-input-container {
            display: flex;
            padding: 10px;
            background-color: #fff;
            border-top: 1px solid #ccc;
        }
        .chat-input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 20px;
            outline: none;
        }
        .button {
            background-color: #075e54;
            color: #fff;
            border: none;
            padding: 10px;
            border-radius: 50%;
            cursor: pointer;
            margin-left: 5px;
        }
        .button:hover {
            background-color: #128c7e;
        }
        #reset-button {
            background-color: #dc3545;
        }
        #reset-button:hover {
            background-color: #c82333;
        }
        .message {
            margin-bottom: 10px;
            display: flex;
            width: 100%;
        }
        .user-message {
            justify-content: flex-end;
        }
        .bot-response {
            justify-content: flex-start;
        }
        .message span {
            padding: 10px;
            border-radius: 7.5px;
            display: inline-block;
            max-width: 80%;
            font-size: 14px;
            word-wrap: break-word;
        }
        .user-message span {
            background-color: #dcf8c6;
            color: #000;
            border: 1px solid #ccc;
        }
        .bot-response span {
            background-color: #fff;
            color: #000;
            border: 1px solid #ccc;
        }
        #teach-container {
            display: none;
            padding: 10px;
            border-top: 1px solid #ccc;
            background-color: #fff;
        }
        .teach-input {
            width: calc(100% - 22px);
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ccc;
            border-radius: 20px;
        }
        /* Stile per la nota */
        .note {
            color: red;
            font-size: 14px;
            margin-top: 10px;
            text-align: center; /* Centra la nota */
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-box" id="chat-box"></div>
        <div class="chat-input-container">
            <input type="text" class="chat-input" id="chat-input" placeholder="Scrivi un messaggio...">
            <button id="send-button" class="button">➤</button>
            <button id="reset-button" class="button">↺</button>
        </div>

        <?php if ($isAdmin): ?>
        <div id="teach-container" style="display: none;">
            <h3>Insegna al Bot</h3>
            <input type="text" class="teach-input" id="teach-keyword" placeholder="Parola chiave">
            <input type="text" class="teach-input" id="teach-response" placeholder="Risposta">
            <div class="button-container">
                <button id="teach-button" class="button">Insegna</button>
                <a href="login.php" class="button">Login</a>
            </div>
            <p class="note">Solo un amministratore può insegnare al bot.</p>
        </div>
        <?php endif; ?>

    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var isAdmin = <?php echo json_encode($isAdmin); ?>;

            document.getElementById('send-button').addEventListener('click', function () {
                sendMessage();
            });

            document.getElementById('chat-input').addEventListener('keypress', function (e) {
                if (e.key === 'Enter') {
                    sendMessage();
                }
            });

            document.getElementById('reset-button').addEventListener('click', function () {
                resetChat();
            });

            function sendMessage() {
                var message = document.getElementById('chat-input').value.trim();
                var chatBox = document.getElementById('chat-box');

                if (message === '') {
                    chatBox.innerHTML += '<div class="message bot-response"><span>Ciao! Come posso aiutarti oggi?</span></div>';
                    chatBox.scrollTop = chatBox.scrollHeight;
                    return;
                }

                document.getElementById('chat-input').value = '';

                chatBox.innerHTML += '<div class="message user-message"><span>' + message + '</span></div>';
                chatBox.scrollTop = chatBox.scrollHeight;

                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'chatbot.php', true);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                xhr.onload = function () {
                    if (this.status === 200) {
                        chatBox.innerHTML += '<div class="message bot-response"><span>' + this.responseText + '</span></div>';
                        chatBox.scrollTop = chatBox.scrollHeight;

                        if (this.responseText === "Mi dispiace, non capisco la tua domanda. Puoi insegnarmi come rispondere?" && isAdmin) {
                            document.getElementById('teach-container').style.display = 'block';
                            document.getElementById('teach-keyword').value = message;
                        } else if (!isAdmin) {
                            alert("Non sei autorizzato a insegnare al bot.");
                        }
                    } else {
                        console.error("Errore nella richiesta:", this.statusText);
                    }
                };
                xhr.onerror = function () {
                    console.error("Errore di rete.");
                };
                xhr.send('message=' + encodeURIComponent(message));
            }

            function resetChat() {
                document.getElementById('chat-box').innerHTML = ''; 
                document.getElementById('chat-input').value = ''; 
                document.getElementById('teach-container').style.display = 'none';
                document.getElementById('teach-keyword').value = '';
                document.getElementById('teach-response').value = '';
            }

            document.getElementById('teach-button').addEventListener('click', function () {
                if (!isAdmin) {
                    alert("Solo un amministratore è autorizzato a insegnare al bot.");
                    return;
                }

                var keyword = document.getElementById('teach-keyword').value;
                var response = document.getElementById('teach-response').value;

                var xhr = new XMLHttpRequest();
                xhr.open('GET', 'chatbot.php?teach=1&keyword=' + encodeURIComponent(keyword) + '&response=' + encodeURIComponent(response), true);
                xhr.onload = function () {
                    if (this.status === 200) {
                        alert(this.responseText);
                        document.getElementById('teach-container').style.display = 'none';
                        document.getElementById('teach-keyword').value = '';
                        document.getElementById('teach-response').value = '';
                    } else {
                        console.error("Errore nella richiesta:", this.statusText);
                    }
                };
                xhr.onerror = function () {
                    console.error("Errore di rete.");
                };
                xhr.send();
            });
        });
    </script>
</body>
</html>
