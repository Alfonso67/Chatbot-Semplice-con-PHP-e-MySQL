<?php
function openDbConnection() {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "bot";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connessione fallita: " . $conn->connect_error);
    }

    return $conn;
}
?>
