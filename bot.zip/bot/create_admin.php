<?php
session_start();
include 'db.php';

$conn = openDbConnection();

// Verifica se l'utente è amministratore
function isAdmin($conn) {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        
        $stmt = $conn->prepare("SELECT is_admin FROM users WHERE id = ?");
        if (!$stmt) {
            die("Errore nella preparazione della query: " . $conn->error);
        }

        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($is_admin);
        $stmt->fetch();
        $stmt->close();

        return $is_admin == 1;
    }
    return false;
}

// Verifica che l'utente sia amministratore
if (!isAdmin($conn)) {
    echo "<script>alert('Accesso non autorizzato. Solo un amministratore può eseguire questa operazione.'); window.location.href = 'login.php';</script>";
    exit;
}

// Gestione della richiesta di creazione dell'utente
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = stripslashes($_POST['username']);
    $password = stripslashes($_POST['password']);

    // Hash della password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $conn->prepare("INSERT INTO users (username, password, is_admin, approved) VALUES (?, ?, ?, ?)");
    if (!$stmt) {
        die("Errore nella preparazione della query: " . $conn->error);
    }

    $is_admin = 1;
    $approved = 0; // Imposta lo stato approved a 0
    $stmt->bind_param("ssii", $username, $hashed_password, $is_admin, $approved);

    if ($stmt->execute()) {
        $message = "Utente amministratore creato con successo. Deve essere approvato prima di poter accedere.";
    } else {
        $message = "Errore durante la creazione dell'utente.";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Crea Amministratore</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .admin-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            text-align: center;
        }
        .admin-container h1 {
            margin-top: 0;
        }
        .admin-container label {
            display: block;
            margin: 15px 0 5px;
        }
        .admin-container input[type="text"],
        .admin-container input[type="password"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
        .button-container {
            display: flex;
            gap: 10px;
        }
        .button-container button {
            flex: 1;
            padding: 10px;
            background-color: #007bff;
            border: none;
            border-radius: 5px;
            color: white;
            font-size: 16px;
            cursor: pointer;
            box-sizing: border-box;
        }
        .button-container button:hover {
            background-color: #0056b3;
        }
        .button-container .login-button {
            background-color: #28a745;
        }
        .button-container .login-button:hover {
            background-color: #218838;
        }
        .admin-container p {
            color: red;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <h1>Crea un Utente Amministratore</h1>
        <form method="post">
            <label for="username">Nome Utente:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <div class="button-container">
                <button type="submit">Crea Amministratore</button>
                <a href="login.php" style="flex: 1;">
                    <button type="button" class="login-button" style="width: 100%;">Login</button>
                </a>
            </div>
        </form>
        <?php if (isset($message)) echo "<p>$message</p>"; ?>
    </div>
</body>
</html>
